importScripts('core.js');
let chain = Promise.resolve();
const enqueue = fn => { const r = chain.then(fn); chain = r.catch(() => {}); return r; };
const pending = new Map();

chrome.action.onClicked.addListener(() => chrome.tabs.create({ url: chrome.runtime.getURL('viewer.html') }));

const saveOrders = async list => {
  const { orders = {} } = await chrome.storage.local.get('orders');
  for (const o of list) orders[o.order_sn] = { ...orders[o.order_sn], ...o };
  await chrome.storage.local.set({ orders, updated: Date.now() }); kick();
};

async function fetchTracking(sn, trk, sns = [sn]) {
  const tab = await chrome.tabs.create({ url: 'https://mobile.pinduoduo.com/goods_express.html?order_sn=' + encodeURIComponent(sn), active: false });
  try {
    const lines = await new Promise((resolve, reject) => {
      const t = setTimeout(() => { pending.delete(sn); reject(new Error('timeout')); }, 30000);
      pending.set(sn, l => { clearTimeout(t); pending.delete(sn); resolve(l); });
    });
    const rec = { tracking_number: trk, timeline: lines, signed: isFinal({ timeline: lines }), fetched_at: Date.now() };
    await enqueue(async () => {
      const { tracking = {} } = await chrome.storage.local.get('tracking');
      sns.forEach(s => { tracking[s] = rec; }); await chrome.storage.local.set({ tracking }); kick();
    });
    return { ok: true };
  } finally { chrome.tabs.remove(tab.id).catch(() => {}); }
}

async function photos(list) {
  const have = await chrome.storage.local.get(list.map(u => 'ph:' + u));
  for (const u of list) {
    if (have['ph:' + u]) continue;
    try {
      const blob = await (await fetch(u)).blob();
      const d = await new Promise(r => { const f = new FileReader(); f.onload = () => r(f.result); f.readAsDataURL(blob); });
      await chrome.storage.local.set({ ['ph:' + u]: d });
    } catch {}
  }
}

chrome.runtime.onMessage.addListener((m, _s, send) => {
  if (m.type === 'orders') { enqueue(() => saveOrders(m.orders)); return false; }
  if (m.type === 'timeline') { const f = pending.get(m.sn); if (f) f(m.lines); return false; }
  if (m.type === 'fetchTracking') { fetchTracking(m.sn, m.trk, m.sns).then(send, e => send({ ok: false, err: String(e) })); return true; }
  if (m.type === 'copyTracking') { enqueue(async () => { const { tracking = {} } = await chrome.storage.local.get('tracking'); m.to.forEach(s => { tracking[s] = tracking[m.from]; }); await chrome.storage.local.set({ tracking }); }).then(() => send({ ok: true })); return true; }
  if (m.type === 'photos') { photos(m.urls).then(() => send({ ok: true })); return true; }
});

// ---- delay alerts: toolbar count + a notification when a parcel newly turns late ----
async function refreshAlerts(notify) {
  const { orders = {}, tracking = {}, alerted = {} } = await chrome.storage.local.get(['orders', 'tracking', 'alerted']);
  const hot = buildParcels(orders, tracking).parcels.filter(a => a.fl && a.fl.sev > 0), red = hot.filter(a => a.fl.sev === 2), next = {};
  chrome.action.setBadgeBackgroundColor({ color: red.length ? '#e02e24' : '#d9822b' });
  chrome.action.setBadgeText({ text: hot.length ? String(hot.length) : '' });
  for (const a of red) {
    next[a.k] = 2;
    if (notify && !alerted[a.k]) chrome.notifications.create('pdd-' + a.k, { type: 'basic', iconUrl: 'icon.png', title: 'Shipment running late', message: `${nameOf(a.r.goods[0]) || a.k}: ${a.fl.txt}` });
  }
  await chrome.storage.local.set({ alerted: next });
}
let kickT; const kick = () => { clearTimeout(kickT); kickT = setTimeout(() => refreshAlerts(true), 3000); };
chrome.alarms.create('hourly', { periodInMinutes: 60 });          // lateness grows with time even without a sync
chrome.alarms.onAlarm.addListener(a => { if (a.name === 'hourly') refreshAlerts(true); });
chrome.runtime.onStartup.addListener(() => refreshAlerts(false));
chrome.runtime.onInstalled.addListener(() => refreshAlerts(false));

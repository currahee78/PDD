// Runs inside the page: looks like a phone, and copies every JSON reply that contains orders.
(() => {
  const UA = 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Mobile/15E148 Safari/604.1';
  const def = (k, v) => { try { Object.defineProperty(Navigator.prototype, k, { get: () => v }); } catch {} };
  def('userAgent', UA); def('platform', 'iPhone'); def('maxTouchPoints', 5); def('vendor', 'Apple Computer, Inc.');
  const walk = (n, out) => {
    if (Array.isArray(n)) n.forEach(x => walk(x, out));
    else if (n && typeof n === 'object') { if (n.order_sn) { out.push(n); return; } for (const k in n) walk(n[k], out); }
  };
  const handle = t => {
    try {
      if (typeof t !== 'string' || (t[0] !== '{' && t[0] !== '[')) return;
      const out = []; walk(JSON.parse(t), out);
      if (out.length) window.postMessage({ __pdd: 1, orders: out }, '*');
    } catch {}
  };
  const f = window.fetch;
  window.fetch = async function (...a) { const r = await f.apply(this, a); try { r.clone().text().then(handle); } catch {} return r; };
  const s = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.send = function (...a) {
    this.addEventListener('load', () => {
      try {
        if (!this.responseType || this.responseType === 'text') handle(this.responseText);
        else if (this.responseType === 'json') handle(JSON.stringify(this.response));
      } catch {}
    });
    return s.apply(this, a);
  };
})();

// ---------- Shipments view: headline, stats, journey strip, parcels with details ----------
let gf = null, LASTP = {}; const openX = new Set();
const phaseOf = k => k <= 4 ? 'cn' : k === 5 ? 'se' : 'sg';

function ship() {
  const el = document.getElementById('ship'); if (!el) return;
  const { parcels, med } = buildParcels(D.orders, D.tracking);
  if (!parcels.length) { el.innerHTML = '<div class="empty">No data yet — run a sync first.</div>'; return; }
  LASTP = {}; parcels.forEach(a => { LASTP[a.k] = a; });
  const now = Date.now(), rec = D.received || {};
  const openP = parcels.filter(a => !a.done), delivered = parcels.filter(a => a.done).sort((a, b) => b.dAt - a.dAt);
  const late = openP.filter(a => a.fl && a.fl.sev > 0).sort((a, b) => b.fl.sev - a.fl.sev || b.inStage - a.inStage), red = late.filter(a => a.fl.sev === 2).length;
  const nextA = openP.filter(a => a.eta).sort((a, b) => a.eta - b.eta)[0];
  const ordersOpen = openP.reduce((s, a) => s + a.rs.length, 0), onWay = openP.reduce((s, a) => s + a.rs.reduce((t, x) => t + amt(x.o), 0), 0);
  const soon = openP.filter(a => a.eta && a.eta - now <= 7 * DAY).length;
  const d0 = new Date(), m0 = new Date(d0.getFullYear(), d0.getMonth(), 1).getTime();
  const paid = rows.filter(r => !skip(r.status) && ms(r.o) >= m0).reduce((s, r) => s + amt(r.o), 0);
  const plural = (n, w) => n + ' ' + w + (n === 1 ? '' : 's');

  const detail = a => {
    const ks = Object.keys(a.ent).map(Number).sort((p, q) => p - q), tl = a.r.trk ? a.r.trk.timeline : [], got = a.rs.filter(y => rec[y.sn]).length;
    const j = ks.map(k => `<div class="jr ${phaseOf(k)}"><b>${ST[k]}</b><span>${dstr(a.ent[k])}</span>${k === a.st && !a.done ? `<div class="sub">${fd(a.inStage)} here${med[k] ? ` · usually ${fd(med[k])}` : ''}</div>` : ''}</div>`).join('')
      + (a.done ? '' : `<div class="jr fut ${phaseOf(9)}"><b>Delivered</b><span>${a.eta ? 'likely by ' + dstr(a.eta) : ''}</span></div>`);
    const inside = a.rs.map(y => { const g = y.goods[0], u = photo(thumbOf(g));
      return `<label class="in"><input type="checkbox" data-got="${esc(y.sn)}" ${rec[y.sn] ? 'checked' : ''}>${u ? `<img loading="lazy" src="${esc(u)}" alt="">` : '<span class="ph"></span>'}<span>${esc(nameOf(g) || y.sn)}${y.goods.length > 1 ? ` +${y.goods.length - 1}` : ''}<br><span class="sub">${esc(pick(g, ['sku_spec', 'spec', 'goods_spec']))} ${amt(y.o) ? yuan(amt(y.o)) : ''}</span></span></label>`; }).join('');
    return `<div class="det"><h5>Journey</h5>${j}${a.allNotes.length ? `<h5>Carrier delay notices</h5>${a.allNotes.map(q => `<div class="sub">${dstr(q.t)} — ${esc(q.text)}</div>`).join('')}` : ''}
      ${a.last ? `<h5>Latest from the carrier</h5><div class="sub">${esc(a.last.text)}</div>` : ''}
      <p><a class="lnk" target="_blank" rel="noopener" href="https://mobile.pinduoduo.com/goods_express.html?order_sn=${encodeURIComponent(a.rs[0].sn)}">Track on PDD ↗</a>${a.r.trk ? ` <button class="lnk" data-copy="${esc(a.r.trk.tracking_number)}">Copy tracking no.</button>` : ''}</p>
      <h5>What's inside · ${plural(a.rs.length, 'order')} · ${got} of ${a.rs.length} received <button class="lnk" data-all="${esc(a.k)}">Tick all</button></h5>${inside}
      ${tl.length ? `<details><summary>All updates (${tl.length})</summary>${tl.map(t => `<div class="sub">${esc(t)}</div>`).join('')}</details>` : ''}</div>`;
  };
  const stack = a => { const im = a.rs.map(x => photo(thumbOf(x.goods[0]))).filter(Boolean).slice(0, 3);
    return `<div class="stack">${im.length ? im.map(u => `<img loading="lazy" src="${esc(u)}" alt="">`).join('') : '<div class="ph"></div>'}${a.rs.length > 1 ? `<i>${a.rs.length}</i>` : ''}</div>`; };
  const row = (a, withStage) => {
    const n = a.rs.length, sum = a.rs.reduce((t, x) => t + amt(x.o), 0), seg = segOf(a.st), isOpen = openX.has(a.k), hasImg = a.rs.some(x => photo(thumbOf(x.goods[0])));
    const title = a.done ? (a.dAt ? 'Delivered ' + (now - a.dAt < DAY ? 'today' : dstr(a.dAt)) : 'Delivered') : (a.eta ? 'Likely by ' + dstr(a.eta) + (a.fl && a.fl.sev === 2 ? ' or later' : '') : ST[a.st]);
    const stats = a.done ? [[a.delT != null ? fdl(a.delT) : '—', 'order to delivery'], [a.age != null ? fdl(a.age) : '—', 'since ordered']]
      : [[a.inStage != null ? fdl(a.inStage) : '—', 'in this stage'], [a.sinceScan != null ? fdl(a.sinceScan) + ' ago' : '—', 'last update'], [a.age != null ? fdl(a.age) : '—', 'since ordered']];
    return `<div class="pr${a.fl ? ' s' + a.fl.sev : ''}" data-x="${esc(a.k)}">${stack(a)}
      <div class="mid"><b>${esc(title)}</b>${withStage ? ` <span class="tag ${seg.c}">${seg.k}</span> <span class="sub">${esc(ST[a.st])}</span>` : ''}
        <div class="sub">${plural(n, 'order')}${sum ? ' · ' + yuan(sum) : ''}${a.r.trk ? ' · …' + esc(String(a.r.trk.tracking_number).slice(-6)) : ''}${hasImg ? '' : ' · ' + esc(nameOf(a.r.goods[0]) || a.r.sn)}</div></div>
      <div class="st3">${stats.map(([v, l]) => `<div><b>${esc(v)}</b><span>${l}</span></div>`).join('')}</div><span class="chev">${isOpen ? '⌄' : '›'}</span>
      ${a.fl ? `<div class="rf s${a.fl.sev}">${a.fl.sev === 2 ? '⚠ ' : ''}${esc(a.fl.txt)}</div>` : ''}</div>${isOpen ? detail(a) : ''}`;
  };
  const grp = (t, list, k) => list.length ? `<div class="gsec"><div class="gh">${k != null ? `<span class="tag ${segOf(k).c}">${segOf(k).k}</span>` : ''}<b>${esc(t)}</b><span class="usu">${k != null && k < 9 ? 'usually ' + (med[k] ? fdl(med[k]) : TYP[k] + ' days') : plural(list.length, 'parcel')}</span></div>${list.map(a => row(a, k == null && t === 'Needs attention')).join('')}</div>` : '';

  const cnt = s => s.st[0] === 9 ? delivered.filter(a => now - a.dAt < 7 * DAY).length : openP.filter(a => s.st.includes(a.st)).length;
  const strip = `<div class="jl">${SEG.map((s, i) => `<button class="js ${s.c}${gf === i ? ' on' : ''}" data-g="${i}"><b>${cnt(s)}</b><i></i><em>${s.short}</em></button>`).join('')}</div>`;
  let body;
  if (gf == null) {
    const rest = openP.filter(a => !late.includes(a));
    body = grp('Needs attention', late) + [8, 7, 6, 5, 4, 3, 2, 1, 0].map(s => grp(ST[s], rest.filter(a => a.st === s).sort((a, b) => b.inStage - a.inStage), s)).join('') + grp('Recently delivered', delivered.slice(0, 8));
  } else { const s = SEG[gf]; body = grp(s.name, s.st[0] === 9 ? delivered : openP.filter(a => s.st.includes(a.st)), s.st[0]); }

  const head = red ? plural(red, 'shipment') + ' running late' : late.length ? plural(late.length, 'shipment') + ' to keep an eye on' : 'Everything is on schedule';
  el.innerHTML = `<div class="hd"><h2>${red ? '⚠' : late.length ? '●' : '✓'} ${head}</h2><div class="sub">${nextA ? `Next to arrive: likely by ${dstr(nextA.eta)}, ${plural(nextA.rs.length, 'order')}.` : 'Nothing on the way.'}</div></div>
    ${strip}
    <div class="strip"><b>${ordersOpen}</b> open orders · <b>${yuan(onWay)}</b> on the way · <b>${soon}</b> likely within 7 days${paid ? ` · <b>${yuan(paid)}</b> paid this month` : ''}</div>
    ${gf != null ? '<div class="meta">Filtered — tap the same leg again to clear.</div>' : ''}${body}
    <div class="meta">“Likely by” uses your own delivered parcels once there are enough, otherwise typical times for this route.</div>`;
}
document.addEventListener('click', e => {
  const b = e.target.closest('[data-g],[data-x],[data-copy],[data-all]'); if (!b) return;
  if (b.dataset.g != null) gf = gf === +b.dataset.g ? null : +b.dataset.g;
  if (b.dataset.x) openX.has(b.dataset.x) ? openX.delete(b.dataset.x) : openX.add(b.dataset.x);
  if (b.dataset.copy) { navigator.clipboard.writeText(b.dataset.copy); b.textContent = 'Copied'; return; }
  if (b.dataset.all) { const a = LASTP[b.dataset.all]; if (a) { const r = Object.assign({}, D.received || {}); a.rs.forEach(y => { r[y.sn] = 1; }); chrome.storage.local.set({ received: r }); } return; }
  ship();
});
document.addEventListener('change', e => {   // "Got it" ticks, kept on this computer
  const c = e.target.closest('[data-got]'); if (!c) return;
  const r = Object.assign({}, D.received || {}); if (c.checked) r[c.dataset.got] = 1; else delete r[c.dataset.got];
  chrome.storage.local.set({ received: r });
});
function alertHtml() {
  const { parcels } = buildParcels(D.orders, D.tracking);
  if (!parcels.length) return '';
  const hot = parcels.filter(a => a.fl && a.fl.sev > 0).sort((a, b) => b.fl.sev - a.fl.sev || b.inStage - a.inStage), red = hot.filter(a => a.fl.sev === 2).length;
  if (!hot.length) return '<div class="sec"><h3>✓ No delayed shipments</h3></div>';
  return `<div class="sec"><h3>⚠ ${red} late · ${hot.length - red} watch</h3>${hot.map(a => `<div class="al s${a.fl.sev}"><b>${esc(nameOf(a.r.goods[0]) || a.k)}${a.rs.length > 1 ? ` +${a.rs.length - 1} more` : ''}</b> · ${ST[a.st]}<br><span class="sub">${esc(a.fl.txt)}</span></div>`).join('')}</div>`;
}
if (typeof rows !== 'undefined' && rows.length) { ship(); if (typeof dash === 'function') dash(); }

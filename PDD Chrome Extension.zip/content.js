(() => {
  const P = location.pathname, sleep = ms => new Promise(r => setTimeout(r, ms));
  const waitFor = async (f, ms) => { const t = Date.now(); while (Date.now() - t < ms && !f()) await sleep(200); };
  const TABS = ['待付款', '待发货', '待收货', '待评价', '退款/售后'];   // edit to match your app
  const MORE = ['查看更多', '展开更多', '更多物流信息', '展开'];
  const TRK = ['tracking_number', 'shipping_id', 'express_no'];
    const isFinal = t => { const L = (t && t.timeline) || []; return L.some(l => /\bdelivered\b|已签收|signed for|签收人/i.test(l) && !/warehouse|仓|consolidation|\[china|china\]|中国/i.test(l)) && L.some(l => /singapore|新加坡/i.test(l)); };
  const doneStatus = o => /评价|交易成功|交易完成|已完成|已收货|确认收货/.test(['order_status_prompt', 'order_status_desc', 'status_desc', 'status_text', 'order_status'].map(k => o[k]).join(' '));
  const norm = u => u.startsWith('//') ? 'https:' + u : u;
  const seen = new Set();
  const ready = () => document.readyState === 'complete' ? Promise.resolve() : new Promise(r => addEventListener('load', r));
  const leaf = (t, exact = true) => [...document.querySelectorAll('div,span,a,li,p,button')]
    .filter(e => !e.children.length && (exact ? e.textContent.trim() === t : e.textContent.includes(t)) && e.getBoundingClientRect().width)
    .sort((a, b) => a.getBoundingClientRect().top - b.getBoundingClientRect().top);

  // bridge: page -> extension storage
  window.addEventListener('message', e => {
    const d = e.data;
    if (e.source !== window || !d || d.__pdd !== 1) return;
    d.orders.forEach(o => seen.add(o.order_sn));
    chrome.runtime.sendMessage({ type: 'orders', orders: d.orders });
  });

  // tracking page: copy the timeline (opened and closed by the extension)
  if (P.endsWith('goods_express.html')) {
    (async () => {
      await ready();
      await waitFor(() => /\d{1,2}[-/.:]\d{2}/.test(document.body.innerText) && document.body.innerText.length > 120, 8000);
      await sleep(300);
      for (const l of MORE) { const e = leaf(l, false)[0]; if (e) { e.click(); await sleep(500); } }
      chrome.runtime.sendMessage({
        type: 'timeline', sn: new URLSearchParams(location.search).get('order_sn'),
        lines: document.body.innerText.split('\n').map(s => s.trim()).filter(Boolean)
      });
    })();
  }

  // order list page: sync panel
  if (P.endsWith('orders.html')) {
    const scrollers = () => [...document.querySelectorAll('*')].filter(el => el.scrollHeight > el.clientHeight + 50 && /auto|scroll/.test(getComputedStyle(el).overflowY));
    const scrollAll = () => { scrollTo(0, document.documentElement.scrollHeight); scrollers().forEach(el => el.scrollTop = el.scrollHeight); };
    const resetScroll = () => { scrollTo(0, 0); scrollers().forEach(el => el.scrollTop = 0); };
    const urls = (n, s = new Set()) => {
      if (Array.isArray(n)) n.forEach(x => urls(x, s));
      else if (n && typeof n === 'object') for (const [k, v] of Object.entries(n))
        (typeof v === 'string' && /^(https?:)?\/\//.test(v) && /thumb|image|img|pic/.test(k)) ? s.add(norm(v)) : urls(v, s);
      return s;
    };
    const FRESH_MS = 3 * 3600e3;                 // quick sync skips parcels checked within this long
    const QUICK_TABS = ['待发货', '待收货'];        // the tabs that hold open orders
    let box, msg, btns = [], known = new Set();
    const say = t => msg.textContent = t;
    const fresh = () => { let c = 0; seen.forEach(s => { if (!known.has(s)) c++; }); return c; };
    async function idle(label, rounds, early) {
      let n = 0, last = seen.size, lastNew = fresh();
      while (n < rounds) {
        scrollAll(); await sleep(1200);
        const grew = seen.size !== last, isNew = fresh() !== lastNew;
        n = grew ? 0 : n + 1;
        if (early && grew && !isNew) break;       // loaded more orders, all already saved -> older history, stop
        last = seen.size; lastNew = fresh(); say(`${label}: ${seen.size} orders`);
      }
    }
    async function run(full) {
      btns.forEach(b => b.disabled = true);
      try {
        const st0 = await chrome.storage.local.get('orders'); known = new Set(Object.keys(st0.orders || {}));
        await idle('全部', full ? 4 : 3, !full);
        for (const t of full ? TABS : QUICK_TABS) {
          resetScroll(); await sleep(400);
          const el = leaf(t)[0];
          if (!el) { say(`tab not found: ${t}`); await sleep(600); continue; }
          el.click(); await sleep(1200); await idle(t, full ? 4 : 2, false);
        }
        await sleep(800);
        const st = await chrome.storage.local.get(['orders', 'tracking']);
        const orders = st.orders || {}, tracking = st.tracking || {}, G = {}, now = Date.now(), todo = [];
        for (const [sn, o] of Object.entries(orders)) { const t = TRK.map(k => o[k]).find(Boolean); if (t) (G[t] = G[t] || []).push(sn); }
        for (const [trk, sns] of Object.entries(G)) {            // one check per parcel, not per order
          const have = sns.filter(s => tracking[s]), signed = have.find(s => isFinal(tracking[s]));
          if (!signed && sns.some(s => doneStatus(orders[s]))) continue;
          if (signed) { if (have.length < sns.length) await chrome.runtime.sendMessage({ type: 'copyTracking', from: signed, to: sns }); continue; }
          if (!full && have.length === sns.length && sns.every(s => now - tracking[s].fetched_at < FRESH_MS)) continue;
          todo.push([trk, sns]);
        }
        for (let i = 0; i < todo.length; i++) {
          say(`Tracking ${i + 1}/${todo.length}`);
          await chrome.runtime.sendMessage({ type: 'fetchTracking', sn: todo[i][1][0], sns: todo[i][1], trk: todo[i][0] });
          await sleep(1000 + Math.random() * 1000);
        }
        const all = [...urls(orders)];
        for (let i = 0; i < all.length; i += 12) {
          say(`Photos ${Math.min(i + 12, all.length)}/${all.length}`);
          await chrome.runtime.sendMessage({ type: 'photos', urls: all.slice(i, i + 12) });
        }
        say(`Done: ${Object.keys(orders).length} orders, ${todo.length} parcels checked.`);
      } catch (e) { say('Error: ' + e.message); }
      btns.forEach(b => b.disabled = false);
    }
    ready().then(() => {
      box = document.createElement('div');
      box.style.cssText = 'position:fixed;right:8px;bottom:8px;z-index:2147483647;background:#fff;color:#222;border:1px solid #ccc;border-radius:10px;padding:8px 10px;font:12px sans-serif;box-shadow:0 2px 8px #0003;max-width:240px';
      const mk = (label, full, bg) => { const b = document.createElement('button'); b.textContent = label; b.style.cssText = `background:${bg};color:#fff;border:0;border-radius:6px;padding:6px 10px;font-size:13px;margin-right:6px`; b.onclick = () => run(full); btns.push(b); return b; };
      msg = document.createElement('div'); msg.style.marginTop = '4px'; msg.textContent = 'Ready';
      box.append(mk('Quick sync', false, '#e02e24'), mk('Full sync', true, '#666'), msg); document.body.append(box);
    });
  }
})();

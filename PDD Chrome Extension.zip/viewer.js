const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const norm = u => u.startsWith('//') ? 'https:' + u : u;
const thumbOf = g => pick(g, ['thumb_url', 'hd_thumb_url', 'goods_thumb_url', 'image_url', 'thumb', 'img_url', 'pic_url']);
const timeOf = o => { const t = pick(o, TIME); if (!t) return ''; const n = Number(t); return n ? new Date(n < 1e12 ? n * 1000 : n).toLocaleString() : String(t); };
const priceOf = o => { const p = pick(o, ['order_amount', 'display_amount', 'total_amount', 'pay_amount']); return p && Number(p) ? '¥' + (Number(p) / 100).toFixed(2) : ''; };
let PA = {}; let D = {}, rows = [], status = '全部', query = ''; const open = new Set();
const photo = u => u ? (D['ph:' + norm(u)] || norm(u)) : '';

async function load() {
  D = await chrome.storage.local.get(null);
  const T = D.tracking || {};
  rows = Object.entries(D.orders || {}).map(([sn, o]) => ({ sn, o, goods: goodsOf(o), status: String(statusOf(o) || '—'), trk: T[sn], ts: Number(pick(o, TIME)) || 0 })).sort((a, b) => b.ts - a.ts);
  PA = {}; buildParcels(D.orders, D.tracking).parcels.forEach(a => a.rs.forEach(x => { PA[x.sn] = a; }));
  chips(); render(); dash(); if (typeof ship === 'function') ship(); if (typeof findView === 'function') findView();
}
function chips() {
  const c = {}; rows.forEach(r => c[r.status] = (c[r.status] || 0) + 1);
  document.getElementById('chips').innerHTML = ['全部', ...Object.keys(c)].map(n =>
    `<button class="chip ${n === status ? 'on' : ''}" data-s="${esc(n)}">${esc(n)} ${n === '全部' ? rows.length : c[n]}</button>`).join('');
}
function render() {
  const q = query.toLowerCase();
  const list = rows.filter(r => (status === '全部' || r.status === status) &&
    (!q || (r.sn + ' ' + (r.trk?.tracking_number || '') + ' ' + r.goods.map(nameOf).join(' ')).toLowerCase().includes(q)));
  document.getElementById('meta').textContent = list.length + ' orders' + (D.updated ? ' · last sync ' + new Date(D.updated).toLocaleString() : '');
  document.getElementById('list').innerHTML = list.length ? list.map(card).join('') :
    `<div class="empty">${rows.length ? 'No orders match.' : 'No orders yet — click “Sync on PDD”, log in if asked, then press Sync orders on the page.'}</div>`;
}
function card(r) {
  const t = r.trk, tl = t?.timeline || [], isOpen = open.has(r.sn);
  const goods = r.goods.map(g => { const u = photo(thumbOf(g));
    return `<div class="g">${u ? `<img loading="lazy" src="${esc(u)}" alt="">` : '<div class="ph"></div>'}<div><div class="gn">${esc(nameOf(g) || '(no name found — see raw)')}</div></div></div>`; }).join('');
  const trk = t ? `<div class="trk"><b>${PA[r.sn] ? (PA[r.sn].done ? 'Delivered' : ST[PA[r.sn].st]) : ''}</b> · ${esc(t.tracking_number)}<div class="sub">${esc(tl[0] || '')}</div>
    <button class="lnk" data-t="${esc(r.sn)}">${isOpen ? 'Hide' : 'Show'} timeline</button>${isOpen ? `<div class="tl">${tl.map(l => `<div>${esc(l)}</div>`).join('')}</div>` : ''}</div>` : '';
  return `<div class="card"><div class="top"><span>${esc(timeOf(r.o))}<br>${esc(r.sn)}</span><span class="st">${esc(r.status)}<br><span class="sub">${esc(priceOf(r.o))}</span></span></div>
    ${goods}${trk}<button class="lnk" data-r="${esc(r.sn)}">raw</button>${open.has('raw' + r.sn) ? `<pre>${esc(JSON.stringify(r.o, null, 1))}</pre>` : ''}</div>`;
}
document.addEventListener('click', e => {
  const b = e.target.closest('[data-s],[data-t],[data-r],[data-v]'); if (!b) return;
  if (b.dataset.v) return show(b.dataset.v);
  if (b.dataset.s) { status = b.dataset.s; chips(); if (b.classList.contains('c')) show('orders'); }
  if (b.dataset.t) open.has(b.dataset.t) ? open.delete(b.dataset.t) : open.add(b.dataset.t);
  if (b.dataset.r) { const k = 'raw' + b.dataset.r; open.has(k) ? open.delete(k) : open.add(k); }
  render();
});
document.getElementById('q').addEventListener('input', e => { query = e.target.value.trim(); render(); });
document.getElementById('sync').onclick = () => window.open('https://mobile.pinduoduo.com/orders.html', '_blank');
const dl = (name, obj) => { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([JSON.stringify(obj, null, 1)], { type: 'application/json' })); a.download = name; a.click(); };
document.getElementById('eo').onclick = () => dl('orders.json', D.orders || {});
document.getElementById('et').onclick = () => dl('tracking.json', D.tracking || {});
let tm; chrome.storage.onChanged.addListener(() => { clearTimeout(tm); tm = setTimeout(load, 800); });
load();

// ---------- dashboard ----------
const amt = o => { const p = Number(pick(o, ['order_amount', 'display_amount', 'total_amount', 'pay_amount'])); return p ? p / 100 : 0; };
const yuan = n => '¥' + n.toLocaleString(undefined, { maximumFractionDigits: 0 });
function show(v) {
  document.querySelectorAll('[data-v]').forEach(b => b.classList.toggle('on', b.dataset.v === v));
  const o = v === 'orders', $ = id => document.getElementById(id);
  $('dash').hidden = v !== 'dash'; $('ship').hidden = v !== 'ship'; $('find').hidden = v !== 'find';
  ['list', 'meta', 'q', 'chips', 'sync'].forEach(id => $(id).hidden = !o);
}
function bars(items, click) {
  const max = Math.max(1, ...items.map(i => i.v));
  return items.map(i => `<div class="br ${click ? 'c' : ''}" ${click ? `data-s="${esc(i.k)}"` : ''}><span class="l" title="${esc(i.k)}">${esc(i.k)}</span><span class="t"><div class="f" style="width:${(i.v / max * 100).toFixed(1)}%"></div></span><span>${esc(i.t)}</span></div>`).join('');
}
function dash() {
  const el = document.getElementById('dash');
  if (!rows.length) { el.innerHTML = '<div class="empty">No data yet — run a sync first.</div>'; return; }
  const paid = rows.filter(r => !skip(r.status)), now = Date.now();
  const spend = paid.reduce((a, r) => a + amt(r.o), 0), has = spend > 0;
  const s30 = paid.filter(r => now - ms(r.o) < 30 * 864e5).reduce((a, r) => a + amt(r.o), 0);
  const PB = buildParcels(D.orders, D.tracking).parcels, transit = PB.filter(a => !a.done && a.r.trk).map(a => a.r), signed = PB.filter(a => a.done).length;
  const kpi = (v, l) => `<div class="kpi"><b>${esc(v)}</b><span>${esc(l)}</span></div>`;
  const M = {}; paid.forEach(r => { const t = ms(r.o); if (!t) return; const k = new Date(t).toISOString().slice(0, 7); (M[k] = M[k] || { n: 0, s: 0 }); M[k].n++; M[k].s += amt(r.o); });
  const months = Object.keys(M).sort().slice(-12).map(k => ({ k, v: has ? M[k].s : M[k].n, t: (has ? yuan(M[k].s) + ' · ' : '') + M[k].n + ' orders' }));
  const S = {}; rows.forEach(r => S[r.status] = (S[r.status] || 0) + 1);
  const stat = Object.entries(S).sort((a, b) => b[1] - a[1]).map(([k, v]) => ({ k, v, t: String(v) }));
  const P = {}; paid.forEach(r => r.goods.forEach(g => { const n = nameOf(g); if (!n) return; const p = P[n] = P[n] || { n: 0, s: 0 }; p.n++; p.s += amt(r.o) / r.goods.length; }));
  const top = Object.entries(P).sort((a, b) => has ? b[1].s - a[1].s : b[1].n - a[1].n).slice(0, 8).map(([k, p]) => ({ k, v: has ? p.s : p.n, t: (has ? yuan(p.s) + ' · ' : '') + p.n + '×' }));
  const tr = transit.slice(0, 10).map(r => `<div class="br" style="grid-template-columns:1fr"><span><b>${esc(nameOf(r.goods[0]) || r.sn)}</b><br><span class="sub">${esc(r.trk.timeline[0] || '')}</span></span></div>`).join('');
  el.innerHTML = (typeof alertHtml === 'function' ? alertHtml() : '') + `<div class="kpis">${kpi(rows.length, 'Orders')}${has ? kpi(yuan(spend), 'Spend (excl. cancelled/unpaid)') + kpi(yuan(spend / Math.max(1, paid.length)), 'Avg order') + kpi(yuan(s30), 'Last 30 days') : ''}${kpi(transit.length, 'In transit')}${kpi(signed, 'Delivered')}</div>
  ${months.length ? `<div class="sec"><h3>${has ? 'Spend' : 'Orders'} by month</h3>${bars(months)}</div>` : ''}
  <div class="sec"><h3>By status (tap to filter)</h3>${bars(stat, true)}</div>
  ${top.length ? `<div class="sec"><h3>Top products by ${has ? 'spend' : 'count'}</h3>${bars(top)}</div>` : ''}
  ${tr ? `<div class="sec"><h3>In transit now</h3>${tr}</div>` : ''}`;
}

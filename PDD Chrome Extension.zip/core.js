// Shared by the viewer (script tag) and the background worker (importScripts). No DOM in here.
const DAY = 864e5, SG = /singapore|新加坡|【sg|\bsg\b/i;
const ST = ['Ordered', 'Seller shipped', 'China last mile', 'Consolidation warehouse', 'China customs', 'In transit (sea)', 'Arrived Singapore', 'Singapore customs', 'Singapore last mile', 'Delivered'];
const LIM = { 1: [4, 8], 2: [5, 10], 3: [10, 16], 4: [5, 8], 5: [10, 16], 6: [3, 5], 7: [4, 7], 8: [4, 7] };   // [amber, red] days in a stage
const ADVISORY = /延迟|延误|拥堵|塞港|暴增|可能有所|影响时效|delay|congest|backlog|peak season|节期间/i;      // carrier notices, not scans
const EXPIRED = /无法为您提供|无法提供.*物流|物流信息已过期|信息已过期|由于时间过长|暂无物流|查询不到/;   // PDD no longer has the carrier's data
const DONE_STATUS = /评价|交易成功|交易完成|已完成|已收货|确认收货/;                               // order status that means the buyer has received it
const TIME = ['order_time', 'create_time', 'order_create_time', 'pay_time'];
const pick = (o, keys) => { for (const k of keys) if (o && o[k]) return o[k]; return ''; };
const ms = o => { const n = Number(pick(o, TIME)); return n ? (n < 1e12 ? n * 1000 : n) : 0; };
const statusOf = o => pick(o, ['order_status_prompt', 'order_status_desc', 'status_desc', 'status_text', 'order_status']);
const nameOf = g => pick(g, ['goods_name', 'name', 'title']);
const goodsOf = o => { const a = o.order_goods || o.goods_list || o.goods || o.items || []; return Array.isArray(a) && a.length ? a : [o]; };
const skip = s => /取消|关闭|待付款|退款/.test(s);
const isFinal = t => { const L = (t && t.timeline) || []; return L.some(l => /\bdelivered\b|已签收|signed for|签收人/i.test(l) && !/warehouse|仓|consolidation|\[china|china\]|中国/i.test(l)) && L.some(l => /singapore|新加坡/i.test(l)); };
const fd = x => { const d = x / DAY; return d < 1 ? Math.max(1, Math.round(d * 24)) + 'h' : d.toFixed(1) + 'd'; };

// [..Singapore..] / [..China..] tags give the country; carrier tags like [SPX Express] are ignored.
const locOf = t => { const m = t.match(/^\s*[\[【]([^\]】]*)[\]】]/); if (!m) return null; if (/singapore|新加坡|\bsg\b/i.test(m[1])) return 'sg'; if (/china|中国/i.test(m[1])) return 'cn'; return null; };
function stageOf(raw, cur) {
  const t = raw.replace(/(目的[地国]|前往|发往|准备发往)[^，。|,.;；]*/g, '').replace(/destination country/ig, '');   // "destination Singapore" != in Singapore
  const loc = locOf(raw), sg = loc === 'sg' || (loc !== 'cn' && SG.test(t)), after = loc !== 'cn' && cur >= 5;
  const wh = /集运仓|warehouse|consolidation|仓库/i.test(t);
  if (!wh && /已签收|签收|delivered|signed for|已送达|已投递|collected by/i.test(t)) return (sg || after) ? 9 : 3;   // signed in China = warehouse received
  if (/待出库|待集运|等待集运|待合包|awaiting consolidation/i.test(raw)) return 3;
  if (/arrive at port|arrived at port|海运到达|berthed|靠泊|等待卸货|awaiting discharge|到港/i.test(raw)) return 6;
  if (/in transit to destination|海运|开始运输|空运|vessel|sailed|sailing|离港|开船|开航|left china|departed (from )?(china|the port|port|airport)|离境|出境|航班|flight|airport|机场|国际运输/i.test(raw)) return 5;
  if (/arrived (at|in) (the )?destination|到达目的|抵达目的|已到达目的地/i.test(raw)) return 6;
  if (/目的国清关|目的地清关|进口清关|destination customs|import customs|customs clearance (in|at) (destination|singapore)/i.test(raw)) return 7;
  if (/派送|派件|out for delivery|delivery attempt|last mile/i.test(t)) return (sg || after) ? 8 : 2;
  if (sg || after) { if (/sorting facility|分拣中心|分拨中心/i.test(t)) return 8; }
  if (sg) {   // customs / arrival need an explicit Singapore tag, not just "after the boat sailed"
    if (/sorting|分拨|分拣|distribution|配送|picked up|从海关发出|local transport|warehouse|仓库/i.test(t)) return 8;
    if (/customs|清关|报关|放行|cleared|released/i.test(t)) return 7;
    if (/抵达|到达|arriv|landed|卸船|discharg/i.test(t)) return 6;
  }
  if (/出库|dispatched from warehouse|集运仓发出|报关|海关|出口|customs declaration|export/i.test(t)) return 4;
  if (cur >= 3 && /发出|outbound|departed/i.test(t)) return 4;
  if (/入库|已入仓|到仓|仓库|集运|合包|consolidat|warehouse|已收货|received/i.test(t)) return 3;
  if (/运输中|在途|in transit/i.test(t)) return cur >= 4 ? 5 : (cur >= 3 ? null : 2);
  if (/打包|packed/i.test(t)) return cur >= 3 ? 3 : 1;
  if (/揽收|已发货|发货|picked up|shipped|collected|商家/i.test(t)) return 1;
  if (/转运|分拨|中转|到达|发往|干线|hub|sorting/i.test(t)) return 2;
  return null;
}
const DS = '(?:(\\d{4})[-/.年])?(\\d{1,2})[-/.月](\\d{1,2})日?(?:[ T]+(\\d{1,2}):(\\d{2})(?::\\d{2})?)?';
const reOnly = new RegExp('^' + DS + '$'), reHead = new RegExp('^' + DS + '\\s+(.+)$'), reTail = new RegExp('^(.+?)\\s+' + DS + '$');
function toT(g, o0) {
  const [y, m, d, h, mi] = g.map(x => x ? +x : 0);
  if (m < 1 || m > 12 || d < 1 || d > 31) return null;
  const n = Date.now(), yy = y || new Date(o0 || n).getFullYear();
  let t = new Date(yy, m - 1, d, h, mi).getTime();
  if (!y) { if (o0 && t < o0 - DAY) t = new Date(yy + 1, m - 1, d, h, mi).getTime(); if (t > n + 2 * DAY) t = new Date(yy - 1, m - 1, d, h, mi).getTime(); }
  return t;
}
function events(lines, o0) {   // pairs each date with its text line, whichever way round the page shows them
  const ev = []; let un = null, wait = null, m;
  for (const raw of lines) {
    const l = raw.trim();
    if ((m = l.match(reOnly))) { const t = toT(m.slice(1, 6), o0); if (t == null) continue; if (un) { ev.push({ t, text: un }); un = null; } else wait = t; }
    else if ((m = l.match(reHead))) { const t = toT(m.slice(1, 6), o0); if (t != null) ev.push({ t, text: m[6] }); }
    else if ((m = l.match(reTail))) { const t = toT(m.slice(2, 7), o0); if (t != null) ev.push({ t, text: m[1] }); }
    else if (l.length > 3) { if (wait != null) { ev.push({ t: wait, text: l }); wait = null; } else un = l; }
  }
  return ev.sort((a, b) => a.t - b.t);
}
function analyse(rs) {
  const r = rs[0], times = rs.map(x => ms(x.o)).filter(Boolean), o0 = times.length ? Math.min(...times) : 0;
  const lines = r.trk?.timeline || [], all = events(lines, o0), now = Date.now(), ent = {}; let st = 0;
  all.forEach(e => { e.adv = ADVISORY.test(e.text); e.exp = EXPIRED.test(e.text); });
  const ev = all.filter(e => !e.adv && !e.exp), allNotes = all.filter(e => e.adv);        // notices never move the stage or count as a scan
  ev.forEach(e => { e.s = stageOf(e.text, st); if (e.s != null) { st = Math.max(st, e.s); if (!(e.s in ent) || e.t < ent[e.s]) ent[e.s] = e.t; } });
  if (!all.length) lines.forEach(l => { if (!ADVISORY.test(l) && !EXPIRED.test(l)) { const s = stageOf(l, st); if (s != null) st = Math.max(st, s); } });
  const done = st === 9 || DONE_STATUS.test(r.status);
  if (done) st = 9;
  if (o0) ent[0] = o0;
  const keys = Object.keys(ent).map(Number).sort((a, b) => a - b), dw = {};
  keys.forEach((k, i) => { if (i < keys.length - 1) dw[k] = ent[keys[i + 1]] - ent[k]; });
  const last = ev.length ? ev[ev.length - 1] : null, cutoff = ent[st] || o0 || 0;
  return { rs, r, o0, st, done, ev, last, dw, ent, allNotes, notes: allNotes.filter(e => e.t >= cutoff), age: o0 ? now - o0 : null,
    sinceScan: last ? now - last.t : null, inStage: ent[st] ? now - ent[st] : (o0 ? now - o0 : null),
    delT: done && ent[9] && o0 ? ent[9] - o0 : null, dAt: ent[9] || (last ? last.t : 0) || o0, expired: lines.some(l => EXPIRED.test(l)) };
}
const CODES = ['CN1', 'CN2', 'CN3', 'CN4', 'CN5', 'SE1', 'SG1', 'SG2', 'SG3', 'SG4'];
const SHORT = ['Ordered', 'Shipped', 'China mile', 'Consolidation', 'China customs', 'At sea', 'Arrived SG', 'SG customs', 'SG mile', 'Delivered'];
const SEG = ST.map((name, i) => ({ k: CODES[i], name, short: SHORT[i], st: [i], c: i <= 4 ? 'cn' : i === 5 ? 'se' : 'sg' }));   // one per stage
const fdl = x => { const h = x / 36e5; if (h < 1) return 'under 1 hour'; if (h < 24) { const n = Math.round(h); return n + (n === 1 ? ' hour' : ' hours'); }
  const d = x / DAY, n = d >= 10 ? Math.round(d) : Math.round(d * 10) / 10; return n + (n === 1 ? ' day' : ' days'); };
const segOf = st => SEG.find(s => s.st.includes(st));
const dstr = t => new Date(t).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' });
const TYP = { 0: 1.5, 1: 1.5, 2: 3, 3: 3, 4: 3.5, 5: 6, 6: 2.5, 7: 2, 8: 2.5 };   // typical days per stage until you have your own history
function etaOf(a, med) {   // time left in this stage + typical time for each stage still to come
  const typ = k => med[k] ? med[k] / DAY : TYP[k];
  let days = Math.max(0.5, typ(a.st) - (a.inStage || 0) / DAY);
  for (let k = a.st + 1; k <= 8; k++) days += typ(k);
  return Date.now() + days * DAY;
}
// sev 1 = watch (amber), 2 = late (red)
function flag(a, med) {
  if (a.done) return null;
  const d = x => x / DAY;
  if (/待成团|拼单/.test(a.r.status)) return { txt: 'Waiting for group to fill', sev: 1 };
  if (a.st === 0 && !a.r.trk && a.age != null && d(a.age) > 3) return { txt: `Not shipped for ${fd(a.age)}`, sev: d(a.age) > 7 ? 2 : 1 };
  if (a.expired && a.st <= 1) return { txt: 'Tracking expired and the order is not marked received yet', sev: 1 };
  const lim = LIM[a.st], m = med[a.st], R = []; let sev = 0;
  let amber = lim ? lim[0] : null, red = lim ? lim[1] : null;
  if (m) { amber = Math.max(2, 1.5 * d(m)); red = Math.max(amber + 1, 3 * d(m)); }       // your own history beats the defaults
  const t = a.inStage != null ? d(a.inStage) : 0, over = amber != null && t > amber, way = red != null && t > red;
  if (over) { R.push(`${fd(a.inStage)} in this stage (${m ? 'usually ' + fd(m) : 'expected within ~' + amber + 'd'})`); sev = way ? 2 : 1; }
  if (a.notes.length) { R.push('Carrier delay notice ' + new Date(a.notes[a.notes.length - 1].t).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })); sev = Math.max(sev, over ? 2 : 1); }
  if (!over && a.sinceScan != null && a.st !== 3 && a.st !== 5 && d(a.sinceScan) > 3) { R.push(`No scan for ${fd(a.sinceScan)}`); sev = Math.max(sev, d(a.sinceScan) > 6 ? 2 : 1); }
  return R.length ? { txt: R.join(' · '), sev } : null;
}
function buildParcels(orders, tracking) {
  const rows = Object.entries(orders || {}).map(([sn, o]) => ({ sn, o, goods: goodsOf(o), status: String(statusOf(o) || '—'), trk: (tracking || {})[sn] })).filter(r => !skip(r.status));
  const P = {}; rows.forEach(r => { const k = r.trk?.tracking_number || r.sn; (P[k] = P[k] || []).push(r); });
  const parcels = Object.entries(P).map(([k, rs]) => Object.assign(analyse(rs), { k })), med = {};
  for (let k = 0; k < 9; k++) { const v = parcels.map(a => a.dw[k]).filter(x => x > 0).sort((a, b) => a - b); if (v.length >= 3) med[k] = v[v.length >> 1]; }
  parcels.forEach(a => { a.fl = flag(a, med); a.eta = a.done ? null : etaOf(a, med); });
  return { parcels, med };
}

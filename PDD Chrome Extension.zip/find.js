// ---------- Find: everything you've bought as photos, with search, filters and stage badges ----------
let fFilter = 'all', fQuery = '';
function findView() {
  const el = document.getElementById('find'); if (!el) return;
  const items = rows.map(r => ({ r, a: PA[r.sn], can: /取消|关闭|退款/.test(r.status) })).sort((x, y) => y.r.ts - x.r.ts);
  const F = { all: items, way: items.filter(i => !i.can && i.a && !i.a.done), done: items.filter(i => !i.can && i.a && i.a.done), can: items.filter(i => i.can) };
  const names = { all: 'All', way: 'On the way', done: 'Delivered', can: 'Cancelled or refunded' };
  const tile = ({ r, a, can }) => {
    const g = r.goods[0], u = photo(thumbOf(g)), s = a && !a.done && !can ? segOf(a.st) : null;
    return `<div class="tile"><div class="ti">${u ? `<img loading="lazy" src="${esc(u)}" alt="">` : ''}${s ? `<span class="tag ${s.c}">${s.k} ${s.short}</span>` : ''}${can ? '<span class="tag x">Cancelled</span>' : ''}</div>
      <div class="tp"><b>${amt(r.o) ? yuan(amt(r.o)) : ''}</b><span>${ms(r.o) ? dstr(ms(r.o)) : ''}</span></div><div class="tn">${esc(nameOf(g) || r.sn)}</div></div>`;
  };
  const draw = () => {
    const q = fQuery.toLowerCase(), list = F[fFilter].filter(i => !q || (i.r.sn + ' ' + i.r.goods.map(nameOf).join(' ')).toLowerCase().includes(q));
    document.getElementById('fgrid').innerHTML = list.length ? list.map(tile).join('') : '<div class="empty">Nothing found.</div>';
  };
  el.innerHTML = `<input id="fq" type="search" placeholder="Search your purchases" value="${esc(fQuery)}">
    <div class="chips">${Object.keys(F).map(k => `<button class="chip ${k === fFilter ? 'on' : ''}" data-f="${k}">${names[k]} ${F[k].length}</button>`).join('')}</div>
    <div class="grid" id="fgrid"></div>`;
  draw();
  document.getElementById('fq').addEventListener('input', e => { fQuery = e.target.value.trim(); draw(); });
  el.querySelectorAll('[data-f]').forEach(b => b.addEventListener('click', () => { fFilter = b.dataset.f; findView(); }));
}
if (typeof rows !== 'undefined' && rows.length) findView();
